//menu
var menu = document.getElementById('menu');
var mb = document.getElementById('mb');
var close = document.getElementById('close');

menu.onclick = function(){
    mb.style.width = '100%';
}

close.onclick = function(){
    mb.style.width = '0px'
}

function submitResult() {
    var form = this;
    var name = document.getElementsByName('user_name')[0].value;
    var password = document.getElementsByName('user_password')[0].value;
    if(name!='' && password!='' && name == 'admin' && password == 'admin'){
        form.submit();
    }
    else {
        alert('Ви ввели неправильні дані');
        return false;
    }
}
    
