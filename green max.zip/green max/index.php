<?php
session_start();
$host = 'localhost';
$user = 'david2ey_product';
$pass = 'LSd30*oj';
$db_name = 'david2ey_product';
$conn = new mysqli($host, $user, $pass, $db_name);
if (isset($_POST['submit'])) {
    $src = $_POST['src'];
    $name = $_POST['name'];
    $price = $_POST['price'];
    $description = $_POST['description'];
    $category = $_POST['category'];
    $sql = "INSERT INTO products (name, price, description, category, src)
VALUES ('$name', '$price', '$description','$category','$src')";
    $conn->query($sql);
}
if (isset($_POST['cabinet_submit'])) {
    $name = $_POST['user_name'];
    $password = $_POST['user_password'];
    if ($name == 'admin' && $password == 'admin') {
        $_SESSION['admin'] = true;
    }
}
if (isset($_POST['cabinet_logout'])) {
    session_destroy();
}
header('Location: /index.html');
?>