<?php
$host = 'localhost';
$user = 'david2ey_product';
$pass = 'LSd30*oj';
$db_name = 'david2ey_product';
$id = $_GET['id'];
$conn = new mysqli($host, $user, $pass, $db_name);
$sql = "SELECT * FROM products WHERE id=$id";
$list = [];
foreach ($conn->query($sql) as $row) {
    $list[] = $row;
}
if(isset($_POST['submit'])){
    $src = $_POST['src'];
    $name = $_POST['name'];
    $price = $_POST['price'];
    $description = $_POST['description'];
    $category = $_POST['category'];
    $sql = "UPDATE products SET name='$name', price='$price', description='$description', category='$category',src='$src' WHERE id=$id";
    if($conn->query($sql)){
        header("Location: /good.php?id=".$id);
    };
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css/main.css">
    <title>Green Max | Догляд за оселею</title>
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link  href="https://cdnjs.cloudflare.com/ajax/libs/fotorama/4.6.4/fotorama.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Nanum+Gothic&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/media.css">
    <link rel="icon" sizes="192x192" href="https://static.wixstatic.com/media/815f02_e88b006f2b9145ebb5b59fb3cfae5958%7Emv2.png/v1/fill/w_32%2Ch_32%2Clg_1%2Cusm_0.66_1.00_0.01/815f02_e88b006f2b9145ebb5b59fb3cfae5958%7Emv2.png">
</head>
<body>
    <div class="wrap">
            <p id="bbt"><a id="" href="catalog.php">Повернутися в каталог</a></p>
        <?php if (!empty($list)):?>
            <form action="#" method="post">
                <div class="good">
                    <div class="photo-title">
                        <img src="images/<?php echo $list[0]['src']?>.jpg" alt="Фото товару">
                    </div>
                    <div class="photo-title">
                        <input id="field" type="text" name="src" placeholder="Введіть url фото" value="<?php echo $list[0]['src']?>" required>
                    </div>
                    <div class="goods-opus">
                       <input type="text" name="name" value="<?php echo $list[0]['name']?>" placeholder="Введіть назву" required>
                    </div>
                    <div class="goods-op">
                        <textarea name="description" placeholder="Введіть опис" style="resize:vertical" required><?php echo $list[0]['description']?></textarea>
                    </div>
                    <div class="price">
                        <input type="text" name="price" value="<?php echo $list[0]['price']?>" placeholder="Введіть ціну" required>
                    </div>
                    <div class="category">
                        <select name="category">
                            <option value="1">Прання</option>
                            <option value="2">Миття посуду</option>
                            <option value="3">Прибирання</option>
                            <option value="4">Догляд за домом</option>
                        </select>
                    </div>
                    <input type="submit" name="submit" value="Зберегти">
                </div>
            </form>
        <?php endif?>
    </div>
</body>
</html>