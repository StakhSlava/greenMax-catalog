<?php
$host = 'localhost';
$user = 'david2ey_product';
$pass = 'LSd30*oj';
$db_name = 'david2ey_product';
$id = $_GET['category'];
$conn = new mysqli($host, $user, $pass, $db_name);
$sql = "SELECT * FROM products WHERE category=$id";
$list = [];
foreach ($conn->query($sql) as $row) {
    $list[] = $row;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css/main.css">
    <title>Green Max | Догляд за оселею</title>
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link  href="https://cdnjs.cloudflare.com/ajax/libs/fotorama/4.6.4/fotorama.css" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Nanum+Gothic&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/media.css">
    <link rel="icon" sizes="192x192" href="https://static.wixstatic.com/media/815f02_e88b006f2b9145ebb5b59fb3cfae5958%7Emv2.png/v1/fill/w_32%2Ch_32%2Clg_1%2Cusm_0.66_1.00_0.01/815f02_e88b006f2b9145ebb5b59fb3cfae5958%7Emv2.png">
</head>
<body>
    <div class="wrap">
        <header>
            <div class="logo">
                <img id="logo" src="images/logo.jpg" alt="Лого сайту">
            </div>
            <div class="menu-navigation">
                <div class="menu-desctop">
                    <span id="menu-position"><a class="color-position-2" id="menu-a" href="index.html">Головна</a></span>
                    <span id="menu-position"><a class="color-position-2" id="menu-a" href="catalog.php">Каталог</a></span>
                    <span id="menu-position"><a class="color-position-2" id="menu-a" href="our.php">Про нас</a></span>
                    <span id="menu-position"><a class="color-position-2" id="menu-a" href="buy.php">Де купити?</a></span>
                </div>
                <div class="menu-mobile">
                    <img id="menu" src="images/menu.jpg" alt="іконка меню">
                    <div id="mb" class="menu-mob">
                        <span id="close">&#10006;</span>
                        <div class="mbli">
                            <span id="retreat"><a class="color-position-3" id="menu-a" href="index.html">Головна</a></span>
                            <span id="retreat"><a class="color-position-3" id="menu-a" href="catalog.php">Каталог</a></span>
                            <span id="retreat"><a class="color-position-3" id="menu-a" href="our.php">Про нас</a></span>
                            <span id="retreat"><a class="color-position-3" id="menu-a" href="buy.php">Де купити?</a></span>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <p></p>
        <div class="catalog-goods">
            <?php foreach ($list as $item) : ?>
                <div class="good">
                    <div class="photo-title">
                        <img src="images/goods1.jpg" alt="Фото товару">
                    </div>
                    <div class="goods-opus">
                        <?php echo $item['name']?>
                    </div>
                    <div class="goods-op">
                        <?php echo $item['description']?>
                    </div>
                    <div class="price">
                        Ціна: <?php echo $item['price']?>грн
                    </div>
                    <p id="btn-goods"><a id="color-a" href="good.php?id=<?php echo $item['id']?>">Переглянути товар</a></p>
                </div>
            <?php endforeach ?>
        </div>
    </div>

<div class="basement">
    <div class="basement-content">
        <div class="text-basement">
            <span id="menu-position"><a class="color-position-3" id="menu-a" href="index.html">Головна</a></span>
            <span id="menu-position"><a class="color-position-3" id="menu-a" href="catalog.php">Каталог</a></span>
            <span id="menu-position"><a class="color-position-3" id="menu-a" href="our.php">Про нас</a></span>
            <span id="menu-position"><a class="color-position-3" id="menu-a" href="buy.php">Де купити?</a></span>
        </div>

        <div class="text-basement">
            <span><a id="social" href="#">Instagram</a></span>
            <span><a id="social" href="#">Facebook</a></span>
            <span><a id="social" href="#">Twitter</a></span>
        </div>
    </div>
    <p id="psevdo">
        © 2020 GreenMax. Всі права захищені
    </p>
</div>
</div>
</body>
<!-- підключення слайдера-->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/fotorama/4.6.4/fotorama.js"></script>
<script src="js/script.js"></script>
</html>