<?php
session_start();
$host = 'localhost';
$user = 'david2ey_product';
$pass = 'LSd30*oj';
$db_name = 'david2ey_product';
$id = $_GET['id'];
$del = $_GET['del'];
$conn = new mysqli($host, $user, $pass, $db_name);
$sql = "SELECT * FROM products WHERE id=$id";
$list = [];
foreach ($conn->query($sql) as $row) {
    $list[] = $row;
}

if(isset($del)){
    $sql = $conn->query("DELETE FROM `products` WHERE `id` = {$_GET['id']}");
    if ($sql) {
        header('Refresh:1; url=/index.html');
        echo "<p>Товар видалено.</p>";
    } else {
        echo '<p>Виникла помилка: '.mysqli_error($conn).'</p>';
    }
}?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css/main.css">
    <title>Green Max | Догляд за оселею</title>
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link  href="https://cdnjs.cloudflare.com/ajax/libs/fotorama/4.6.4/fotorama.css" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Nanum+Gothic&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/media.css">
    <link rel="icon" sizes="192x192" href="https://static.wixstatic.com/media/815f02_e88b006f2b9145ebb5b59fb3cfae5958%7Emv2.png/v1/fill/w_32%2Ch_32%2Clg_1%2Cusm_0.66_1.00_0.01/815f02_e88b006f2b9145ebb5b59fb3cfae5958%7Emv2.png">
</head>
<body>
    <div class="wrap">
            <p id="bbt"><a id="" href="catalog.php">Повернутися в каталог</a></p>
        <?php if (!empty($list)):?>
                <div class="good">
                    <div class="photo-title">
                        <img src="images/<?php echo $list[0]['src']?>.jpg" alt="Фото товару">
                    </div>
                    <div class="goods-opus">
                       <?php echo $list[0]['name']?>
                    </div>
                    <div class="goods-op">
                        <?php echo $list[0]['description']?>
                    </div>
                    <div class="price">
                        Ціна: <?php echo $list[0]['price']?>грн
                    </div>
                        <?php if (isset($_SESSION['admin'])) :?>
                    <div class="delete">
                        <a href="?id=<?php echo $list[0]['id']?>&del=true">Видалити</a>
                    </div>
                    <div class="update">
                        <a href="redact.php?id=<?php echo $list[0]['id']?>">Редагувати</a>
                    </div>
                        <?php endif?>
                </div>
        <?php endif?>
    </div>
</body>
</html>